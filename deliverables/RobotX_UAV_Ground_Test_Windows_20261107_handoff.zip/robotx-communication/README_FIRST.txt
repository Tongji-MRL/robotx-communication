﻿RobotX UAV Windows ground-test handoff 2026-11-07

先阅读 docs/RobotX_UAV_Ground_Test_Windows_20261107.docx。
解压此包到 C:\RobotX，得到 C:\RobotX\robotx-communication。
本包为文档第二版配套代码快照，文件内容以 FILES_SHA256.txt 为准。
仅包含单 UAV 地面通信入口、配置、必要模块、官方生成的 schema 和相关测试。
外发 ID 默认 UAV1；ROS JSON 来源默认 UAV1；ROS topic 不变。
同一入口 --scenario normal / outside-course / over-height，负例仍转发真实 ROS 心跳。
Windows OCS 须在已测通的 ROS 2 环境运行；Python >=3.10。
不包含 ROS 2、Python、Docker 引擎、Docker 镜像或真实设备配置。
电脑 B 按手册单独下载并固定官方 robocommand 仓库版本。
不要在此 OCS 包的 RobotX_2026 目录执行 docker compose；它只包含 schema。
官方 Compose 文件位于单独的 robocommand/RobotX_2026 目录。

可选离线测试：
在 OCS 包根目录，用装有 requirements.txt 的 Python 执行：
python -m unittest discover -s OCS -p "test_*.py"
这些测试不连接真实 UAV 或官方服务器；四条集成流程使用本机 loopback MQTT。
测试范围及限制见 VALIDATION.txt；文件完整性见 FILES_SHA256.txt。
